/**
 * @file: app.js
 * @Author: duanwentao
 */

import React from 'react';
import {HashRouter as Router, Route, Switch} from 'react-router-dom';
import load from 'react-loadable';
import Layout from './pages/layout.js';
import Proute from './router/index.js';
import L from './components/loading/loading.js';
const NotFound = load({loader: () => import('./components/notfound/notfound.js'), loading: L});

export default class App extends React.Component {
    render() {
        return (
            <Router>
                <div>
                    <Switch>
                        <Route path="/404" component={NotFound} />
                        <Route path ="/" render={() =>
                            <Layout>
                                <Proute />
                            </Layout>
                        } />
                    </Switch>
                </div>
            </Router>
        );
    }
}
