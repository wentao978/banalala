/**
 * @file data.js
 */

export const data = [
    {
        title: '灵感创意',
        icon: 'lgcy.png',
        list: [
            {
                text: 'Dribbble',
                content: '发现世界顶级设计师和创意人士',
                icon: 'dribbble.png',
                tclassname: 'didot',
                url: ' https://dribbble.com'
            },
            {
                text: '花瓣',
                content: '陪你做生活的设计师',
                icon: 'hb.png',
                url: 'https://huaban.com'
            },
            {
                text: 'FWA',
                content: '设计作品集合',
                icon: 'fwa.png',
                url: 'https://thefwa.com/awards/page/1/'
            },
            {
                text: 'Bestfolios',
                content: '产品、界面、插画灵感设计集合',
                icon: 'bestfolios.png',
                url: 'https://www.bestfolios.com/home'
            },
            {
                text: 'Panda',
                content: '设计作品和资讯文摘订阅平台',
                icon: 'panda.png',
                url: 'https://usepanda.com/app/#/'
            },
            {
                text: 'lapa',
                content: '登录页面设计灵感',
                icon: 'lapa.png',
                url: 'https://www.lapa.ninja/'
            },
            {
                text: 'One Page Love',
                content: '单页式网页设计平台',
                icon: 'onepagelove.png',
                url: 'https://onepagelove.com/'
            },
            {
                text: 'MUZIL',
                content: '设计灵感资源汇合',
                icon: 'muzil.png',
                url: 'https://muz.li/'
            },
            {
                text: 'MUUUUU',
                content: 'UE设计平台-网页设计、设计交流...',
                icon: 'muuuuu.png',
                url: 'http://muuuuu.org/'
            },
            {
                text: 'ABDUZEEDO',
                content: '日常设计灵感集合',
                icon: 'abduzeedo.png',
                url: 'https://abduzeedo.com/'
            },
            {
                text: 'DesignBetter',
                content: '提升你的设计思维',
                icon: 'designbetter.png',
                url: 'https://www.designbetter.co/'
            },
            {
                text: 'Aerolab',
                content: '设计案例详细记录',
                icon: 'aerolab.png',
                url: 'https://aerolab.co/'
            },
            {
                text: 'Siteinspire',
                content: '那些小众而独具美感的网站',
                icon: 'siteinspire.png',
                url: 'https://www.siteinspire.com/'
            },
            {
                text: 'UpLabs',
                content: '安卓iOS页面设计每日灵感',
                icon: 'uplabs.png',
                url: 'https://www.uplabs.com/'
            },
            {
                text: 'Reeoo',
                content: '网页设计灵感及酷站分享',
                icon: 'reeoo.png',
                url: 'http://reeoo.com/'
            },
            {
                text: 'BestWebGallery',
                content: '优秀网页设计网站搜罗',
                icon: 'bestwebgallery.png',
                url: 'http://bestwebgallery.com/'
            },
            {
                text: 'Straightline',
                content: '日本优美网页设计',
                icon: 'straightline.png',
                url: 'http://bm.straightline.jp/'
            },
            {
                text: 'UI Garage',
                content: '高级美、ui设计灵感炸裂之地',
                icon: 'uigarage.png',
                url: 'https://uigarage.net/'
            },
            {
                text: 'AWWWARDS',
                content: '世界各地超赞的网页设计',
                icon: 'awwwards.png',
                url: 'https://www.awwwards.com/'
            },
            {
                text: 'Mobbin',
                content: 'IOS移动设计灵感库',
                icon: 'mobbin.png',
                url: 'https://mobbin.design/'
            },
            {
                text: 'OnePageMania',
                content: '单页面CSS网站设计欣赏',
                icon: 'onepagemania.png',
                url: 'https://www.onepagemania.com/'
            },
            {
                text: '大作',
                content: '高级美、ui设计灵感炸裂之地',
                icon: 'dz.png',
                url: 'http://www.bigbigwork.com/'
            }
        ]
    },
    {
        title: '界面交互',
        icon: 'jmjh.png',
        list: [
            {
                text: '站酷',
                content: '设计师互动平台',
                icon: 'zcool.png',
                url: 'https://www.zcool.com.cn/'
            },
            {
                text: 'UI中国',
                content: '专业用户体验平台',
                icon: 'uichina.png',
                url: 'https://www.ui.cn/'
            },
            {
                text: 'UEDNA',
                content: 'UE设计平台-网页设计、设计交流...',
                icon: 'uedna.png',
                url: 'http://www.uedna.com/'
            },
            {
                text: '优阁网',
                content: '专业用户体验平台',
                icon: 'ygw.png',
                url: 'http://www.uigreat.com/'
            },
            {
                text: 'UI 8',
                content: 'UI资源交易平台',
                icon: 'ui8.png',
                url: 'https://www.ui8.net/'
            },
            {
                text: '优设网',
                content: '设计师交流学习平台',
                icon: 'ysw.png',
                url: 'https://www.uisdc.com/'
            },
            {
                text: '学UI网',
                content: 'UI设计师学习教程的平台',
                icon: 'xuiw.png',
                url: ' https://xueui.com/'
            },
            {
                text: '莫贝网',
                content: 'UI设计师学习教程的平台',
                icon: 'mbw.png',
                url: 'http://www.mobileui.cn/'
            },
            {
                text: '模库 MCOOL',
                content: '优质商业素材尽在模库',
                icon: 'mcool.png',
                url: 'http://51mockup.com/'
            }
        ]
    },
    {
        title: '图片素材',
        icon: 'tpsc.png',
        list: [
            {
                text: 'Stocksnap',
                content: '高分辨率可商用大图',
                icon: 'stocksnap.png',
                url: 'https://stocksnap.io/search/Mac'
            },
            {
                text: '500PX',
                content: '全球著名摄影师图片展示和售卖平台',
                icon: '500px.png',
                url: 'https://500px.com/popular'
            },
            {
                text: 'Unsplash',
                content: '高质量免费版权的图库素材',
                icon: 'unsplash.png',
                url: 'https://unsplash.com/'
            },
            {
                text: 'Gratisography',
                content: '免费高清图库',
                icon: 'gratisography.png',
                url: 'https://gratisography.com/'
            },
            {
                text: 'Pixabay',
                content: '精品免费图库分享',
                icon: 'pixabay.png',
                url: 'https://pixabay.com/'
            },
            {
                text: 'Splitshire',
                content: '免费高清摄影图库',
                icon: 'splitshire.png',
                url: 'https://www.splitshire.com/'
            },
            {
                text: 'HDwallpapers',
                content: '高清壁纸图片分享网站',
                icon: 'hdwallpapers.png',
                url: 'https://www.hdwallpapers.net/'
            },
            {
                text: 'BingGallery',
                content: '微软必应搜索精美壁纸画廊',
                icon: 'binggallery.png',
                url: 'https://cn.bing.com/'
            },
            {
                text: '123RF',
                content: '企业摄影和创意素材正版图片库',
                icon: '123rf.png',
                url: 'https://www.123rf.com.cn/'
            },
            {
                text: 'FoodiesFeed',
                content: '专注于免费视频图片素材的分享',
                icon: 'foodiesfeed.png',
                url: 'https://www.foodiesfeed.com/'
            },
            {
                text: 'Magdeleine',
                content: '免费高清灵感图片',
                icon: 'magdeleine.png',
                url: 'https://magdeleine.co/'
            },
            {
                text: 'Pexels',
                content: '高品质免费高清图片网站',
                icon: 'pexels.png',
                url: 'https://www.pexels.com/'
            }
        ]
    },
    {
        title: '设计规范',
        icon: 'sjgf.png',
        list: [
            {
                text: 'Material Design',
                content: 'Material Design设计指南',
                icon: 'materialdesign.png',
                url: 'https://www.mdui.org/design/'
            },
            {
                text: 'APPLE developer',
                content: 'IOS人机介面设计指南',
                icon: 'appledeveloper.png',
                url: 'https://developer.apple.com/design/'
            },
            {
                text: 'Ant Densign',
                content: 'Ant Densign设计指南',
                icon: 'antdesign.png',
                url: 'https://ant.design/docs/spec/introduce-cn'
            },
            {
                text: 'SAP',
                content: 'SAP Fiori设计指南 ',
                icon: 'sap.png',
                url: 'https://experience.sap.com/fiori-design-web/'
            },
            {
                text: 'AntV',
                content: '数据可视化设计原则',
                icon: 'antv.png',
                url: 'https://antv.alipay.com/zh-cn/vis/design/index.html'
            },
            {
                text: 'Microsoft Fluent',
                content: 'Microsoft Fluent设计系统',
                icon: 'microsoftfluent.png',
                url: 'https://fluent.microsoft.com/'
            },
            {
                text: 'iPhone尺寸',
                content: 'iPhone设备屏幕尺寸信息参数',
                icon: 'iphonesize.png',
                url: 'https://www.paintcodeapp.com/news/ultimate-guide-to-iphone-resolutions'
            },
            {
                text: '安卓尺寸',
                content: 'Google安卓主流设备尺寸',
                icon: 'anroidsize.png',
                url: 'https://material.io/tools/devices/'
            },
            {
                text: 'Screensize',
                content: '移动屏幕尺寸规范',
                icon: 'screensize.png',
                url: 'http://screensiz.es/phone'
            }
        ]
    },
    {
        title: '图标设计',
        icon: 'tbsj.png',
        list: [
            {
                text: 'Iconfont',
                content: '阿里团队图标字体素材下载',
                icon: 'iconfont.png',
                url: 'http://www.iconfont.cn/'
            },
            {
                text: 'iconmoon',
                content: '矢量图打包成图标字体的技术平台',
                icon: 'iconmoon.png',
                url: 'https://icomoon.io/'
            },
            {
                text: 'iconstore',
                content: '免费商用的高品质图标素材网站',
                icon: 'iconstore.png',
                url: 'https://iconstore.co/'
            },
            {
                text: 'Easyicon',
                content: '图标搜索大全 ',
                icon: 'easyicon.png',
                url: 'https://www.easyicon.net/'
            },
            {
                text: 'Logodust',
                content: '提供开源免费的logo',
                icon: 'logodust.png',
                url: 'http://logodust.com/'
            },
            {
                text: 'icon8',
                content: '系统平台风格和web图标库',
                icon: 'icon8.png',
                url: 'https://icons8.com/'
            },
            {
                text: 'IOSicongallery',
                content: 'IOS平台app图标收录和欣赏',
                icon: 'iosicongallery.png',
                url: 'https://www.iosicongallery.com/'
            },
            {
                text: 'iconninja',
                content: '图标搜索可生成css sprites',
                icon: 'iconninja.png',
                url: 'http://www.iconninja.com/'
            },
            {
                text: 'iconfinder',
                content: '高质量付费图标',
                icon: 'iconfinder.png',
                url: 'https://www.iconfinder.com/'
            },
            {
                text: 'themify',
                content: '免费iconfont下载',
                icon: 'themify.png',
                url: 'https://themify.me/themify-icons'
            },
            {
                text: 'Fontello',
                content: '在线生成web font 字体',
                icon: 'fontello.png',
                url: 'http://fontello.com/'
            }
        ]
    },
    {
        title: '色彩搭配',
        icon: 'scdp.png',
        list: [
            {
                text: 'AdobeColor',
                content: 'Adobe专业配色工具',
                icon: 'adobecolor.png',
                url: 'https://color.adobe.com/zh/'
            },
            {
                text: 'Colorhunt',
                content: '每天更新一组配色方案',
                icon: 'colorhunt.png',
                url: 'https://colorhunt.co/'
            },
            {
                text: 'Colorfavs',
                content: '创建和发现美丽的调色板和颜色',
                icon: 'colorfavs.png',
                url: 'http://www.colorfavs.com/'
            },
            {
                text: 'Coolors',
                content: '在线快速配色生成工具 ',
                icon: 'coolors.png',
                url: 'https://coolors.co/'
            },
            {
                text: 'Nipponcolors',
                content: '日本の伝統色',
                icon: 'nipponcolors.png',
                url: 'http://nipponcolors.com/'
            },
            {
                text: 'Webgradients',
                content: '新鲜的背景渐变',
                icon: 'webgradients.png',
                url: 'https://webgradients.com/'
            },
            {
                text: 'Mesh Gradients',
                content: '流行的网格简便背景免费下载',
                icon: 'meshgradients.png',
                url: 'https://lstore.graphics/meshgradients/'
            },
            {
                text: '中国色',
                content: '中国传统颜色',
                icon: 'chinase.png',
                url: 'http://zhongguose.com/'
            },
            {
                text: 'Material Design配色',
                content: 'material design在线配色神器',
                icon: 'materialps.png',
                url: 'https://www.materialpalette.com/'
            },
            {
                text: 'uigradients',
                content: '在线生成高大上的渐变色',
                icon: 'uigradients.png',
                url: 'https://uigradients.com/#Lithium'
            },
            {
                text: 'Coolhue',
                content: '很棒的色卡',
                icon: 'coolhue.png',
                url: 'https://webkul.github.io/coolhue/'
            },
            {
                text: '云配色',
                content: '在线查询制定网站的配色、css等信息',
                icon: 'cloudse.png',
                url: 'http://card.qdsay.com/'
            }
        ]
    },
    {
        title: '在线工具',
        icon: 'zxgj.png',
        list: [
            {
                text: 'TinyPNG',
                content: '在线压缩png/jpg工具',
                icon: 'tinypng.png',
                url: 'https://tinypng.com/'
            },
            {
                text: 'CloudConvert',
                content: '云端在线图片格式转换',
                icon: 'cloudconvert.png',
                url: 'https://cloudconvert.com/'
            },
            {
                text: 'img.top',
                content: '智能在线图片压缩',
                icon: 'imgtop.png',
                url: 'https://img.top/'
            },
            {
                text: 'Optimizilla',
                content: '支持jpeg／png在线压缩工具',
                icon: 'optimizilla.png',
                url: 'https://imagecompressor.com/'
            },
            {
                text: '智图',
                content: '图片压缩在线工具',
                icon: 'zhiimage.png',
                url: 'https://zhitu.isux.us/'
            },
            {
                text: 'waifu2x',
                content: '在线将小图无损放大的工具',
                icon: 'waifu2x.png',
                url: 'http://waifu2x.udp.jp/'
            },
            {
                text: 'Canva',
                content: '在线设计作图工具',
                icon: 'canva.png',
                url: 'https://www.canva.com/'
            },
            {
                text: '百度脑图',
                content: '在线思维导图工具',
                icon: 'bdnt.png',
                url: 'http://naotu.baidu.com/'
            },
            {
                text: '比特虫',
                content: '在线生成favicon',
                icon: 'bitec.png',
                url: 'http://www.bitbug.net/'
            },
            {
                text: 'Fluid',
                content: '移动原型在线设计工具',
                icon: 'fluid.png',
                url: 'https://www.fluidui.com/'
            },
            {
                text: '墨刀',
                content: '在线图片转图标',
                icon: 'modao.png',
                url: 'https://free.modao.cc/'
            },
            {
                text: 'iConvert icons',
                content: '在线图片转图标',
                icon: 'iconverticons.png',
                url: 'https://iconverticons.com/online/'
            },
            {
                text: '草料二维码',
                content: '二维码生成、美化等服务',
                icon: 'clqrcode.png',
                url: ' https://cli.im/'
            },
            {
                text: 'QRHacker',
                content: '二维码在线制作工具',
                icon: 'qrhcker.png',
                url: 'https://www.qrhacker.com/'
            },
            {
                text: 'Transfonter',
                content: '在线font-face生成工具',
                icon: 'transfonter.png',
                url: 'https://transfonter.org/'
            },
            {
                text: 'Smallpdf',
                content: 'pdf格式互转、压缩等功能',
                icon: 'smallpdf.png',
                url: 'https://smallpdf.com/cn'
            },
            {
                text: 'Preloaders',
                content: 'loading加载动画在线制作',
                icon: 'preloaders.png',
                url: 'https://icons8.com/preloaders/'
            },
            {
                text: 'Mockplus',
                content: '简洁高效原型设计工具',
                icon: 'mockplus.png',
                url: 'https://www.mockplus.cn/'
            },
            {
                text: 'Figma',
                content: '支持多人同时在线设计工具',
                icon: 'figma.png',
                url: 'https://www.figma.com/'
            },
            {
                text: 'UXPin',
                content: '在线UI/UX设计工具',
                icon: 'uxpin.png',
                url: 'https://www.uxpin.com/'
            },
            {
                text: 'Photopea',
                content: '在线ps工具',
                icon: 'photopea.png',
                url: 'https://www.photopea.com/'
            },
            {
                text: 'Pixlr',
                content: '在线ps绘图工具',
                icon: 'pixlr.png',
                url: 'https://pixlr.com/'
            }
        ]
    },
    {
        title: '软件/插件',
        icon: 'rjcj.png',
        list: [
            {
                text: 'Sketch',
                content: 'MAC 上ui/ux设计神器',
                icon: 'sketch.png',
                url: 'https://sketchapp.com/'
            },
            {
                text: 'Affinity Designer',
                content: '媲美ps的设计软件新秀',
                icon: 'affinity.png',
                url: 'https://affinity.serif.com/zh-cn/'
            },
            {
                text: 'Adobe Photoshop',
                content: '数字图像设计的全新体验',
                icon: 'photoshop.png',
                url: 'https://www.adobe.com/cn/products/photoshop.html'
            },
            {
                text: 'Adobe Illustrator',
                content: '矢量图形设计',
                icon: 'illustrator.png',
                url: 'https://www.adobe.com/cn/products/illustrator.html'
            },
            {
                text: 'Adobe After Effects',
                content: '数字动画／动效设计软件',
                icon: 'aftereffects.png',
                url: 'https://www.adobe.com/cn/products/aftereffects.html'
            },
            {
                text: 'Adobe Animate ',
                content: '矢量动画设计软件',
                icon: 'animate.png',
                url: 'https://www.adobe.com/cn/products/animate.html'
            },
            {
                text: 'Squash 2',
                content: '图片压缩与软件优化',
                icon: 'squash.png',
                url: 'https://www.realmacsoftware.com/squash/'
            },
            {
                text: 'Pixelmator',
                content: '轻型mac版图像设计',
                icon: 'pixelmator.png',
                url: 'https://www.pixelmator.com/mac'
            },
            {
                text: 'Cinema 4D',
                content: '三维动画解决方案',
                icon: 'cinema4d.png',
                url: 'https://www.maxon.net/cn/'
            },
            {
                text: 'GuideGuide',
                content: '快速轻松创建网格.扩展',
                icon: 'guideguide.png',
                url: 'https://guideguide.me/'
            },
            {
                text: 'Cutterman',
                content: '最好的切图工具',
                icon: 'cutterman.png',
                url: 'http://www.cutterman.cn/zh/cutterman'
            },
            {
                text: 'Sketch Measure',
                content: '丰富便捷的标注功能，支持html格式',
                icon: 'measure.png',
                url: 'http://utom.design/measure/'
            },
            {
                text: 'Map Generator 2.0',
                content: '自动生成地区.扩展',
                icon: 'mapgenerator.png',
                url: ' https://maps-generator.com/'
            },
            {
                text: 'Sketch.im',
                content: 'sketch插件集合',
                icon: 'Sketchim.png',
                url: 'http://www.sketch.cm/plugins/'
            },
            {
                text: 'Eagle',
                content: '图片管理工具',
                icon: 'eagle.png',
                url: 'https://cn.eagle.cool/'
            },
            {
                text: '蓝湖',
                content: '简单好用的团队工作台',
                icon: 'bluehu.png',
                url: 'https://lanhuapp.com/?home'
            }
        ]
    },
    {
        title: '素材下载',
        icon: 'scxz.png',
        list: [
            {
                text: '千图网',
                content: '设计素材下载',
                icon: 'qtuw.png',
                url: 'http://www.58pic.com/'
            },
            {
                text: 'Vecteezy',
                content: '发现下载免费矢量艺术',
                icon: 'vecteezy.png',
                url: 'https://www.vecteezy.com/'
            },
            {
                text: '365psd',
                content: '免费psd、图像、矢量文件',
                icon: '365psd.png',
                url: 'https://cn.365psd.com/'
            },
            {
                text: '图翼网',
                content: '设计素材分享',
                icon: 'tuyiw.png',
                url: 'http://www.tuyiyi.com/'
            },
            {
                text: '美工云',
                content: '海外设计素材分享',
                icon: 'meigong.png',
                url: 'http://www.meigongyun.com/'
            },
            {
                text: '90设计',
                content: '矢量动画设计软件',
                icon: '90sj.png',
                url: 'http://90sheji.com/'
            },
            {
                text: '大美工',
                content: '设计优选',
                icon: 'dameigong.png',
                url: 'http://dameigong.cn/'
            }
        ]
    },
    {
        title: '设计团队',
        icon: 'sjtd.png',
        list: [
            {
                text: 'TGideas',
                content: '腾讯游戏官方设计团队',
                icon: 'tgideas.png',
                url: 'https://tgideas.qq.com/'
            },
            {
                text: '腾讯CDC',
                content: '腾讯用户研究与体验设计中心',
                icon: 'txcdc.png',
                url: 'https://cdc.tencent.com/'
            },
            {
                text: '腾讯ISUX',
                content: '腾讯社交用户体验设计',
                icon: 'txisux.png',
                url: 'https://isux.tencent.com/'
            },
            {
                text: '百度EUX',
                content: '百度企业产品用户体验中心',
                icon: 'bdeux.png',
                url: 'http://eux.baidu.com/'
            },
            {
                text: '百度UXC',
                content: '百度用户体验中心',
                icon: 'bduxc.png',
                url: 'http://mux.baidu.com/'
            },
            {
                text: '阿里妈妈MUX',
                content: '阿里妈妈mux',
                icon: 'alimux.png',
                url: 'https://mux.alimama.com/index.html'
            },
            {
                text: '阿里巴巴',
                content: '阿里巴巴国际UED团队',
                icon: 'aliued.png',
                url: 'http://www.aliued.com/'
            },
            {
                text: 'U一点',
                content: '阿里巴巴用户体验设计部',
                icon: 'udot.png',
                url: 'http://www.aliued.cn/'
            },
            {
                text: 'EICO',
                content: '数字化咨询与产品设计',
                icon: 'eico.png',
                url: 'http://eicoinc.com/'
            },
            {
                text: '360UXC',
                content: '360用户体验设计中心',
                icon: '360uxc.png',
                url: 'http://uxc.360.cn/'
            },
            {
                text: '京东JDC',
                content: '京东设计中心',
                icon: 'jdc.png',
                url: 'http://jdc.jd.com/'
            },
            {
                text: 'Facebook Design',
                content: 'Facebook设计团队网站',
                icon: 'facebook.png',
                url: 'https://facebook.design/'
            },
            {
                text: 'Tubik Studio',
                content: '优秀团队的集合',
                icon: 'tubik.png',
                url: 'https://tubikstudio.com/'
            }
        ]
    },
    {
        title: '前端开发',
        icon: 'qdkf.png',
        list: [
            {
                text: 'Element',
                content: 'element 网站快速成型工具',
                icon: 'element.png',
                url: 'http://element-cn.eleme.io/#/zh-CN'
            },
            {
                text: 'Ant Design',
                content: '蚂蚁金服ui语言',
                icon: 'antdesignicon.png',
                url: 'https://ant.design/index-cn'
            },
            {
                text: 'AUI',
                content: '轻量级ui框架',
                icon: 'aui.png',
                url: 'http://www.auicss.com/'
            },
            {
                text: 'PURE',
                content: '响应迅速的css模块',
                icon: 'pure.png',
                url: 'https://purecss.io/'
            },
            {
                text: 'AlloyTeam',
                content: '腾讯全端',
                icon: 'alloyteam.png',
                url: 'http://www.alloyteam.com/'
            },
            {
                text: '百度FEX',
                content: '百度前端研发部',
                icon: 'bdfex.png',
                url: 'http://fex.baidu.com/'
            },
            {
                text: 'AIPage',
                content: '百度智能建站',
                icon: 'aipage.png',
                url: 'https://aipage.baidu.com/'
            },
            {
                text: 'W3Cplus',
                content: '引领web前端',
                icon: 'w3cplus.png',
                url: 'https://www.w3cplus.com/'
            },
            {
                text: 'Bootstrap',
                content: '最受欢迎css、js、html框架',
                icon: 'bootstrap.png',
                url: 'https://v3.bootcss.com/'
            },
            {
                text: 'Semantic UI',
                content: '用户界面web语言',
                icon: 'semantic.png',
                url: 'http://www.semantic-ui.cn/'
            },
            {
                text: 'Ant Design Pro',
                content: '蚂蚁金服ui语言',
                icon: 'antdpro.png',
                url: 'https://preview.pro.ant.design/dashboard/analysis'
            },
            {
                text: 'Aurelia',
                content: 'Js客户端框架',
                icon: 'aurelia.png',
                url: 'https://aurelia.io/'
            },
            {
                text: 'Laravel',
                content: '简洁php web开发框架',
                icon: 'laravel.png',
                url: 'https://laravel.com/'
            },
            {
                text: 'Flat UI',
                content: '扁平风格ui',
                icon: 'flatui.png',
                url: 'http://designmodo.github.io/Flat-UI/'
            },
            {
                text: 'Flutter',
                content: '谷歌跨平台原生框架',
                icon: 'flutter.png',
                url: 'https://flutter.io/'
            },
            {
                text: 'Vuejs',
                content: '渐进式js框架',
                icon: 'vuejs.png',
                url: 'https://cn.vuejs.org/'
            },
            {
                text: 'React',
                content: 'facebook强大js框架',
                icon: 'react.png',
                url: 'https://reactjs.org/'
            },
            {
                text: 'Material UI',
                content: '最受欢迎轻量react ui框架',
                icon: 'materialui.png',
                url: 'https://material-ui.com/'
            },
            {
                text: 'Material Design Lite',
                content: '谷歌官方轻量级materialdesign...',
                icon: 'materialdesignlite.png',
                url: 'https://getmdl.io/'
            },
            {
                text: ' JQuery',
                content: '快速简洁的js框架',
                icon: 'jquery.png',
                url: 'http://jquery.com/'
            }
        ]
    }
];
