/**
 * @file: router.js
 * @Author: duanwentao
 */

import React from 'react';
import {Switch, Redirect, Route} from 'react-router-dom';
import load from 'react-loadable';
import L from '../components/loading/loading.js';

const Home = load({loader: () => import('../pages/home'), loading: L});
const About = load({loader: () => import('../pages/about'), loading: L});
const Work = load({loader: () => import('../pages/work'), loading: L});
const Inspiration = load({loader: () => import('../pages/inspiration'), loading: L});
const Intouch = load({loader: () => import('../pages/intouch'), loading: L});
const Jump = load({loader: () => import('../pages/jump'), loading: L});

export default class Routex extends React.Component {
    render() {
        return (
            <Switch>
                <Route exact path="/" component={Home} />
                <Route path="/about" component={About} />
                <Route path="/work" component={Work} />
                <Route path="/inspiration" component={Inspiration} />
                <Route path="/jump" component={Jump} />
                <Route path="/intouch" component={Intouch} />
                <Redirect to="/404" />
            </Switch>
        );
    }
}
