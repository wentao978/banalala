/**
 * @file: intouch.js
 * @Author: duanwentao
 */

import React from 'react';

export default class Intouch extends React.Component {
    render() {
        return (
            <div>
                intouch
            </div>
        );
    }
}
