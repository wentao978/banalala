/**
 * @file: inspiration.js
 * @Author: duanwentao
 */

import React from 'react';
import {Link} from 'react-router-dom';
import $ from 'jquery';
import {data} from '../data/data';

const requireContext = require.context('../data/images/inspiration', true, /^\.\/.*\.png$/);
const projectImgs = requireContext.keys().map(requireContext);

export default class Inspiration extends React.Component {
    state = {
        collapsed: false
    }

    handleMouseOver = (e, img) => {
        console.log('img', $(e.target), img);
    }

    componentDidMount() {
        let arr = [];
        $('.box').each(function (i) {
            arr.push($('.box').eq(i).offset().top);
        });
        arr.push(arr[arr.length - 1] + 2000);

        function goto(n, i) {
            let top = $('.' + n).eq(i).offset().top;
            $('body,html').animate({scrollTop: top}, 300);
        }

        $('.menu a').on('click', function () {
            goto('box', $(this).index());
        });

        // $(window).scroll(function () {
        //     $.each(arr, function (index) {
        //         if ($(window).scrollTop() >= arr[index] && $(window).scrollTop() < arr[index + 1]) {
        //             $('.m').eq(index).addClass('on').siblings().removeClass('on');
        //         }
        //     });
        // });
        let $links = $('.link-item');
        $(window).on('scroll', function () {
            let cHeight = document.documentElement.clientHeight; // 浏览器可见区域高度
            $.each($links, function (index, item) {
                let $item = $(item);
                if (!item.show
                    && $item.length
                    && $item.get(0)
                    && $item.get(0).getBoundingClientRect().top + $item.height() > 0
                    && $item.get(0).getBoundingClientRect().top < cHeight
                ) {
                    $item
                        .append('<img src=' + $item.data('bg') + ' class="on" />')
                        .removeAttr('data-bg');
                    item.show = true;
                }
            });
        }).trigger('scroll');
    }

    render() {
        return (
            <div className="inspiration">
                <div className="ins-sidebar menu">
                    <div className="logo-wrap">
                        ddd
                    </div>
                    <div className="link-wrap">
                    {
                        data.map((item, index) =>
                            <a key={index} className="f12 m">
                                <span className="icon-wrap fl">
                                    <span className="icon"></span>
                                </span>
                                <span className="menu-title fl">{item.title}</span>
                            </a>)
                    }
                    </div>
                </div>
                <div className="ins-main">
                    <div className="ins-nav">
                        <div className="spread fr"></div>
                    </div>
                    <div className="ins-content">
                        {
                            data.map((item, index) => {
                                return <div className="box ohx" key={index}>
                                        <div className="title f12">
                                            <span>{item.title}</span>
                                        </div>
                                        <div className="box-content ohx">
                                            {
                                                item.list.map((d, i) => {
                                                    let img = projectImgs.filter(icon => icon.includes(d.icon))[0];
                                                    return <Link key={i} className="fl"
                                                                to={`/jump?url=${d.url}`} target="_blank"
                                                            >
                                                                <div className="img-wrap fl link-item" data-bg={img}></div>
                                                                <div className={`text fl f14 cb dotted ${/[\w|\s]+/g.test(d.text) ? 'didot' : ''}`}>{d.text}</div>
                                                                <div className="content fl f12 c3 dotted">{d.content}</div>
                                                            </Link>;
                                                })
                                            }
                                        </div>
                                    </div>;
                            })
                        }
                    </div>
                </div>
            </div>
        );
    }
}
