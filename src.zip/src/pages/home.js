/**
 * @file: home.js
 * @Author: duanwentao
 */

import React from 'react';
import {Link} from 'react-router-dom';
import $ from 'jquery';
// import feather from '../data/images/feather.png';

export default class Home extends React.Component {
    componentDidMount() {
        let oImg = new Image();
        oImg.src = 'http://localhost:8000/static/media/feather.png';

        // <path d="M15 0A4 4 0 1 0 15 8A4 4 0 1 0 15 0Z" stroke="lightgrey" strokeWidth="0" fill="none" id="go"/>
        $('.link-work').hover(() => {
            // console.log('over');
            // $('#feather').css('display', 'block');
            // $('#mpath').attr('xlink:href', '#go');
            // $('.svg').append($(g));
            // $('.svg').get(0).appendChild(gEl);
            // $('.svg').get(0).appendChild(pathEl);
            const svgEl = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            svgEl.setAttribute('class', 'svg');
            svgEl.setAttribute('width', '50');
            svgEl.setAttribute('height', '50');

            const gEl = document.createElementNS('http://www.w3.org/2000/svg', 'g');
            // gEl.style.transform = 'translateX(15px)';
            // const imageEl = document.createElementNS('http://www.w3.org/2000/svg', 'image');
            const pathEl = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            const animateMotionEl = document.createElementNS('http://www.w3.org/2000/svg', 'animateMotion');

            animateMotionEl.setAttribute('begin', '0s');
            animateMotionEl.setAttribute('dur', '1.5s');
            animateMotionEl.setAttribute('path', 'M0 0A4 4 0 1 0 0 8A4 4 0 1 0 0 0Z');
            animateMotionEl.setAttribute('repeatCount', 'indefinite');

            pathEl.setAttribute('d', 'M14,21.3264428 C16.2327657,18.0324074 17.8640267,15.6847954 18.8937829,14.2836068 C24.3116882,6.91146733 28.6638257,2.56376681 31.9501953,1.2405053 C38.2851562,-1.31027595 39.0986328,0.45339592 39.0986328,3.09890373 C39.0986328,4.86257561 37.4290365,6.39480217 34.0898438,7.69558342 C32.3307292,13.079047 28.5426432,15.7707787 22.7255859,15.7707787');
            pathEl.setAttribute('fill', '#55adcf');
            // let datasrc = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAAsCAYAAAAq/ZsdAAAAAXNSR0IArs4c6QAABMxJREFUaAXtWk1sG0UUnjdrO6EULCACpBBF/KSpY29ISVAAUfFzo4mcRLRIVBWIQxE/ohIHDvRQJXBA4oDIAYQAqRUVXFIRuyEtUhGUBtQgNaKNvU7VQikEVaAqVQAlZLM/jzdWndqxd7O7Xjs+MJednXl/3755782MDazG25bxTLOm41Y0cSsw1s0AGxAhTP0/qX+Ch+r3TW9r+T0Hg8Zrr8lfnLuL6douZOZ2RCbbWwhzQSZ1nR6IXBR0AXvi6s0ifXY5OdPPmLnH1JcfYfTuTDveooP5BtE+I+gdMjkT7ZVKHs30IxhD5I12bzJgThmINQjedQUUS164jeHCBwSEPFNeC/Fg4499my/x8sR4525PKNvRXMz4AUZYoUlaWDyrDmgQkUcT6bcMNEcYw5uFEX40wBAKOVVdcp3Hfg6rC4ufkld6/ACxIgNAvfHW8E0nH2r6t2pZTsSLurBwjMCskYZXzHTcAQYJAUYwVGXJieJI8TJRETDAFiEQ3JtDX3FA7cmzrZpmTlC8tOSU+vUEYDpwvjPVu+lCTqaU61TieV9SuUdD8wQVyUbf5QP8DZw9lY7HxvJlVwxQLJFq0pEdJ8/cka/Qlz7ARFDivdPx2ORqeRVJCiIBUMx8RWCaVyss6x3gogRs8Ew8+gkAZNP0anm+p+2rqdnfBACgcGDDocbogaku0FaDyH/31UOdpzC4NKt8Tgr8Sc3kBc6hJxWPHs032q7va5YjMB/RMnvcTqHLua/dgBGyfQMkJ5R9BOZZlwbbkgOHD20JSkz6AiiWVHaZaA6VkO95iIL7cuRulnAroGxAseTZLjqc0VLzuQF7dyQaXXYrtSxA2fOMqY1S4ax3q9iWntJzQ3jjO7Y0FpOeAYmMRrXmEBUD3wunxOC144/duWRhs+2wZ0DqbGaYksDDttK9TAJ8Od0fPeSFVfB4AkQZ7Tm6kXnRq1JLPoCfeOCGnZbzDiZc7xTkxIyMqP9AS+06B/Kdk4jNZgAfSPfKM86ZiildeejRb5SNyPQRv8HQMWAeEPvKBSPgudr6XJ5HUehai7+L9xEC8wtZ0eMHGGGFYw9R8XyBksDT3k0v5iQwR4Kh+m6/wAgNjmKoY1Tp0AAnqd7UFZvlZQTO00nz1XRf27gXbjueNQF1jl3aoBpzU3QfsNlOkLM5+A4YHohs4ge97AKc6FgzhlTjyrBXMGI/hgBTtA6+51Los9zZP+3EMo80th6KJTIDiIY431g2EqAhg/10dPmVrpP+YgDzBOAKmmY63S/PWjJWaMIS0P3jyu2LGqYobrKX4KX0E/NJSeK76UislJpfjzHLJUdg9luCAfiHA+x9Mt72/iCAuR6GW+ks6SG6e36JwLxXkgngsBSqezn/V7OSdOs0WASoYyzTohvGaUoEGwpsAviDvLIn1RelS/babQWFdQeipBnmwQIwFO10ZfRxEK+P1DoY8ZkLYihzWHmdllr3te8P5ziXnk/FI99eG6vt3sqSuzepbDFMU+yigzSoMeBvN4VCbx7d1qLWNoRC67KAnjhyvm5WXTpFYGK0v5rkAWn3dG9bJetfoRU+vmWX3G/L6hAVxGYK+ldqMRW7wRuQx2YeRENvpT8wtIlUnHLDXYu0Yiddi3b9b9PVL/AfXGGnpv3f6LwAAAAASUVORK5CYII=';
            // imageEl.setAttribute('xlink:href', datasrc);
            // imageEl.setAttribute('src', datasrc);
            // imageEl.setAttribute('stroke', 'lightgrey');
            // imageEl.setAttribute('strokeWidth', '0');
            // imageEl.setAttribute('width', '26');
            // imageEl.setAttribute('height', '22');
            // imageEl.href.baseVal = datasrc;

            // gEl.appendChild(imageEl);
            gEl.appendChild(pathEl);
            gEl.appendChild(animateMotionEl);

            svgEl.appendChild(gEl);
            $('.link-div').get(0).appendChild(svgEl);
            // $('.svg').find('g').css('transform', 'translateX(-14px)');
            // $('#animate').get(0).setAttributeNS('http://www.w3.org/2000/svg', 'dur', '1.5s');
        }, () => {
            // console.log('out');
            // $('#feather').css('display', 'none');
            // $('#mpath').attr('xlink:href', '');
            // svgEl.parentNode.removeChild(svgEl);
            $('.svg').remove();
        });
    }
    render() {
        return (
            <div>
                <div className="nav">
                    <div className="nav-left didot f20"></div>
                    <div className="nav-right cp f20">
                    </div>
                </div>
                <div className="header auto pr">
                    <div className="header-left"></div>
                    <div className="header-right"></div>
                    <ul className="nav-icon pa auto">
                        <li className="didot f18 work-li">
                            <Link to='/work' className="link-work" style={{width: 68}}>
                                <div className="pr link-div">
                                    <p className="d1 pa"></p>
                                    <p className="d2 pa"></p>
                                    {/* <svg width="50" height="50" className="svg pa">
                                        <g>
                                            <image id="feather" xlinkHref="/static/media/feather.png" stroke="lightgrey" strokeWidth="1" src="/static/media/feather.png" width="26" height="22" />
                                            <path d="M14,21.3264428 C16.2327657,18.0324074 17.8640267,15.6847954 18.8937829,14.2836068 C24.3116882,6.91146733 28.6638257,2.56376681 31.9501953,1.2405053 C38.2851562,-1.31027595 39.0986328,0.45339592 39.0986328,3.09890373 C39.0986328,4.86257561 37.4290365,6.39480217 34.0898438,7.69558342 C32.3307292,13.079047 28.5426432,15.7707787 22.7255859,15.7707787" id="work-pen"></path>
                                            <animateMotion path="M15 0A4 4 0 1 0 15 8A4 4 0 1 0 15 0Z" dur="1.5s" repeatCount="indefinite" id="animate">
                                            </animateMotion>
                                        </g>
                                    </svg> */}
                                </div>
                                <span>My Work</span>
                            </Link>
                        </li>
                        <li className="didot f18 contact-li">
                            <Link to='/inspiration' style={{width: 84}}>
                                <div className="pr">
                                    <p className="d1 pa"></p>
                                    <p className="d2 pa"></p>
                                </div>
                                <span>Inspiration</span>
                            </Link>
                        </li>
                        <li className="didot f18 me-li">
                            <Link to='/about' style={{width: 74}}>
                                <div className="pr">
                                    <p className="me-d1 pa"></p>
                                    <p className="me-d2 pa"></p>
                                    <p className="me-d3 pa"></p>
                                </div>
                                <span>About Me</span>
                            </Link>
                        </li>
                        <li className="didot f18 inspiration-li">
                            <Link to='/intouch' style={{width: 93}}>
                                <div className="pr">
                                    <p className="d1 pa"></p>
                                    <div className="d2 pa"><p className="d3 pa"></p></div>
                                </div>
                                <span>Get in touch</span>
                            </Link>
                        </li>
                    </ul>
                </div>
            </div>
        );
    }
}
