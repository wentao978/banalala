/**
 * @file: jump.js
 * @Author: duanwentao
 */

import React from 'react';
import $ from 'jquery';

export default class Jump extends React.Component {

    getQueryString = name => {
        let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
        let r = window.location.hash.split('?')[1].match(reg);
        if (r != null) {
            return unescape(r[2]);
        }
        return null;
    }

    componentDidMount() {
        setTimeout(() => {
            $('.mloading').hide();
            window.location.replace(this.getQueryString('url'));
        }, Math.random() * 500 + 500);
    }

    render() {
        return (
            <div className="mloading">
                <div></div>
                <div></div>
            </div>
        );
    }
}
