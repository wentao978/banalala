/**
 * @file: work.js
 * @Author: duanwentao
 */

import React from 'react';

export default class Work extends React.Component {
    render() {
        return (
            <div>
                work
            </div>
        );
    }
}
