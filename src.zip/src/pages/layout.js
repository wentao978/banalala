/**
 * @file: layout.js
 * @Author: duanwentao
 */

import React from 'react';
import {withRouter} from 'react-router-dom';
// import {Button} from 'antd';

@withRouter
export default class Layout extends React.Component {
    render() {
        // let pathname = this.props.location.pathname;
        return (
            <div>
                {/* <Link replace={pathname === '/about'} to='about'><Button className="didot">关于</Button></Link>
                <Link replace={pathname === '/work'} to='work'><Button className="didot">work</Button></Link>
                <Link replace={pathname === '/inspiration'} to='inspiration'>inspiration</Link>
                <Link replace={pathname === '/intouch'} to='intouch'>intouch</Link> */}
                {this.props.children}
            </div>
        );
    }
}
