/**
 * @file: about.js
 * @Author: duanwentao
 */

import React from 'react';

export default class About extends React.Component {
    render() {
        return (
            <div>
                about
            </div>
        );
    }
}
