/**
 * @file: index.js
 * @Author: duanwentao
 */

import React from 'react';
import ReactDOM from 'react-dom';
import {LocaleProvider} from 'antd';
import zh_CN from 'antd/lib/locale-provider/zh_CN';
import App from './app';
import {unregister} from './registerServiceWorker';
import './index.less';

class Index extends React.Component {
    render() {
        return (
            <LocaleProvider locale={zh_CN}>
                <App />
            </LocaleProvider>
        );
    }
}

ReactDOM.render(
    <Index />,
    document.getElementById('root')
);

unregister();
