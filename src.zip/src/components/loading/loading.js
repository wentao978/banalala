/**
 * @file: loading.js
 * @Author: duanwentao
 */

import React from 'react';

export default class Loading extends React.Component {
    render() {
        let {error, pastDelay} = this.props;
        if (error) {
            console.error(error);
            return <div>Error!</div>;
        } else if (pastDelay) {
            return <div className="mloading">
                        <div></div>
                        <div></div>
                    </div>;
        } else {
            return null;
        }
    }
}
