/**
 * @file: notfound.js
 * @Author: duanwentao
 */

import React from 'react';

export default class NotFound extends React.Component {
    render() {
        return (
            <div style={{textAlign: 'center', paddingTop: '100px', marginLeft: 'auto', marginRight: 'auto'}}>
                <div style={{fontSize: '180px', fontWeight: 'bolder', color: '#f1f1f1', WebkitTextStroke: '1px #1890ff'}}>
                    404
                </div>
                (ㄒoㄒ)~~不好意思，页面走丢了~~
            </div>
        );
    }
}
